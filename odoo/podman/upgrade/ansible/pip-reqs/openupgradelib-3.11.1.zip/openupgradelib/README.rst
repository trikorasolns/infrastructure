.. image:: https://img.shields.io/travis/OCA/openupgradelib.svg
    :target: https://travis-ci.org/OCA/openupgradelib
    :alt: Build Status

.. image:: https://coveralls.io/repos/OCA/openupgradelib/badge.svg?service=github
  :target: https://coveralls.io/github/OCA/openupgradelib
  :alt: Coverage Status

.. image:: https://codeclimate.com/github/OCA/openupgradelib/badges/gpa.svg
   :target: https://codeclimate.com/github/OCA/openupgradelib
   :alt: Code Climate

.. image:: https://img.shields.io/pypi/v/openupgradelib.svg
   :target: https://pypi.python.org/pypi/openupgradelib
   :alt: Pypi Package

===============================
OpenUpgrade Library
===============================

A library with support functions to be called from Odoo migration scripts.

* Free software: AGPL-3 license
* Documentation: https://oca.github.io/openupgradelib

Install
-------

Always get the latest version through:

pip/pip3 install --ignore-installed git+https://github.com/OCA/openupgradelib.git@master

Features
--------

* TODO
