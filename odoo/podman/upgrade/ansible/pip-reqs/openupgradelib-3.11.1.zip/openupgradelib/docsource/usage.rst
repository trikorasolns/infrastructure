========
Usage
========

To use OpenUpgrade Library in a project::

    import openupgradelib
