============
Installation
============

At the command line::

    $ easy_install openupgradelib

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv openupgradelib
    $ pip install openupgradelib

In order to be sure you get the latest fixes from openupgradelib it is recommended to install from github::

    $ pip install git+git://github.com/OCA/openupgradelib.git
