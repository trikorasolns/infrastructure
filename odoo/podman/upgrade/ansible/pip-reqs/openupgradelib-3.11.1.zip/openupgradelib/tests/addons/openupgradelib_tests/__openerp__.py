# Copyright 2018 Opener B.V. <https://opener.am>
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).
{
    "name": "Openupgradelib Test Addon",
    "version": "1.0.0",  # No version prefix on purpose
    "category": "Migration",
    "author": "Opener B.V., Odoo Community Association (OCA)",
    "license": "AGPL-3",
    "website": "https://github.com/oca/openupgradelib",
    "installable": True,
}
