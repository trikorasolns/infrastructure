=======
Credits
=======

Development Lead
----------------

* Odoo Community Association <support@odoo-community.org>

Contributors
------------

* Alexandre Fayolle
* Alexis de Lattre
* Arthur Vuillard
* Benoit Guillot
* Bogdan Stanciu
* Christoph Giesel
* Daniel Reis
* David Arnold
* David Béal
* David Vidal
* Dimitrios T. Tanis
* Dmytro Katyukha
* Ernesto Tejeda
* Florent Xicluna
* Florian Dacosta
* Graeme Gellatly
* Hector Villarreal Ortega
* Hervé Martinet
* Holger Brunn
* Ivàn Todorovich
* Jairo Llopis
* Jordi Riera
* Juan Pablo Arias
* Julien Coux
* Katherine Zaoral
* Kay Häusler
* Manuel Vázquez Acosta
* Miku Laitinen
* Miquel Raich
* Moisés López
* Paulius Sladkevičius
* Pedro M. Baeza
* Petar Najman
* Robert Rübner
* Ronald Portier
* Sandy Carter
* Sebastien Alix
* Silvija Butko
* Stefan Rijnhart
* Stephane Le Cornec
* Stéphane Bidoul
* Sylvain LE GAL
* Tom Blauwendraat
* Yann Bongiovanni
* Yuri Quintana
